from time import sleep
import logger as logger
import util as util
import os
import generate_api

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


def safe_click(driver, element, timeout=10):
    """
    要素が表示され、クリック可能になるまで待機してからクリックする関数

    引数:
        driver: Chromeドライバー
        element: クリック対象の要素
        timeout: 待機時間（秒）

    返り値:
        なし

    エラー:
        Exception

    著作権:
        Ryusuke Kimura (ogi.kimura@gmail.com)

    """
    # 画面中央へスクロール
    driver.execute_script(
        "arguments[0].scrollIntoView({block:'center', inline:'center'});", element
    )
    WebDriverWait(driver, timeout).until(lambda d: element.is_displayed() and element.is_enabled())
    # move_to_element してからクリック（被り回避に効くことが多い）
    ActionChains(driver).move_to_element(element).pause(0.1).click().perform()


def scraiping_smartdb(driver, base_url):
    """
    SmartDBのスクレイピングをして情報(金額)を取得する処理

    引数:
        Chromeドライバー、検索サイトURL

    返り値:
        なし

    エラー:
        Exception

    著作権:
        Ryusuke Kimura (ogi.kimura@gmail.com)

    """
    
    download_dir = util.DOWNLOAD_DIR  # 例: r"C:\work\downloads" など
    
    # ==================== ホームページ ======================
    ### ----- ログイン -----
    xpath = "//input[@id='username']"
    res = util.set_textbox(driver, xpath, os.environ.get("SMART_DB_USER"), 0)

    xpath = "//span[contains(@class,'MuiButton-label') and .//div[normalize-space()='次へ']]"
    res = util.xpath_click(driver, xpath, 0)
    
    xpath = "//input[@data-testid='password-input']"
    res = util.set_textbox(driver, xpath, os.environ.get("SMART_DB_PASSWORD"), 0)

    xpath = "//span[normalize-space()='パスワードでログイン']"
    res = util.xpath_click(driver, xpath, 0)
    
    
    ### ----- 一覧表表示から帳票選択 -----
    
    # デバッグ（実施済ボタンクリック）★暫定★(2026/02/08 実際に未実施が表示されるようになれば対応) 
    xpath = "//button[@role='tab' and .//p[normalize-space()='実施済み']]"
    res = util.xpath_click(driver, xpath, 0)
    
    for _ in range(util.ITER_COUNT):
        
        xpath = "//div[@role='button' and .//p[normalize-space()='支払依頼']]"
        elements = util.get_elements_xpath(driver, xpath)
        
        for element in elements:
            
            element_text = element.text
            
            if "支払依頼" in element_text:
                logger.info(f"########## {element_text} 処理 START ##########")
                
                safe_click(driver, element)
            
                ### ----- 新しいウィンドウに切り替え -----
                # 現在のウィンドウハンドルを取得
                original_window = driver.current_window_handle
                # すべてのウィンドウハンドルを取得
                all_windows = driver.window_handles
                # 新しいウィンドウに切り替える
                util.switch_window(driver, all_windows, original_window)
            
                ### ----- 該当帳票からpdfダウンロード -----
                # ダウンロード前のPDF一覧
                before = util.list_pdf_files(download_dir)
                
                xpath = "//a[contains(@class,'TextLink') and contains(@onclick,'dlFolderFile') and contains(@onclick,'.pdf')]"
                res = util.xpath_click(driver, xpath, 0)
                
                # 新規PDFを特定（ファイル名が可変でもOK）
                pdf_path = util.wait_new_pdf(download_dir, before, timeout=60)
                
                ### ----- 生成AIに投げて金額を取得 -----
                total_including_tax, consumption_tax, total_decluding_tax = generate_api.main(pdf_path)
                
            
                ### ----- 該当帳票のhtmlから金額取得 -----
                # 合計金額
                xpath = "//td[@class='data_cell' and @name='13725']//div[contains(@class,'VCenter')]/div"
                element = util.get_elements_xpath(driver, xpath)[0]
                amount_all = element.text
                
                # 差引支払金額
                xpath = "//td[@class='data_cell' and @name='13647']//div[contains(@class,'VCenter')]/div"
                element = util.get_elements_xpath(driver, xpath)[0]
                amount_sashihiki = element.text
                
                # 請求消費税額
                xpath = "//div[@class='smartdb-item' and @itemkey='SEIKYU_ZEI']//div[contains(@class,'VCenter')]/div[@style='display: inline;']"
                element = util.get_elements_xpath(driver, xpath)[0]
                amount_tax = element.text
                
                # ①消費税金額
                xpath = "//td[@class='data_cell' and @name='KARI_KINGAKU_1']//div[contains(@class,'VCenter')]/div"
                element = util.get_elements_xpath(driver, xpath)[0]
                amount_1_tax = element.text
                
                # ①税抜金額
                xpath = "//td[@class='data_cell' and @name='KARI_ZEI_KINGAKU_1']//div[contains(@class,'VCenter')]/div"
                element = util.get_elements_xpath(driver, xpath)[0]
                amount_1_nuki = element.text
            
                ### ----- pdf情報とhtml情報を比較 -----
                f = 0
                if total_including_tax != util.normalize_money(amount_all):
                    f = 1
                    logger.warning(f"pdf合計金額とhtml合計金額が不一致です(pdf:{total_including_tax} html:{amount_all})")
                
                if consumption_tax != util.normalize_money(amount_tax):
                    f = 1
                    logger.warning(f"pdf消費税金額とhtml請求消費税額が不一致です(pdf:{consumption_tax} html:{amount_tax})")
                
                
                try: 
                    if total_decluding_tax + consumption_tax != util.normalize_money(amount_sashihiki):
                        f = 1
                        logger.warning(f"pdf差引支払金額とhtml差引支払金額が不一致です(pdf:{total_decluding_tax + consumption_tax} html:{amount_sashihiki})")
                except TypeError:
                    f = 1
                    logger.warning(f"pdf差引支払金額とhtml差引支払金額が不一致です(pdf:{total_decluding_tax} + {consumption_tax} html:{amount_sashihiki})")
                
                ### ----- 承認ボタンクリック ★暫定★(2026/02/08 実際に承認ボタンが表示されるようになれば対応) -----
                # if f == 0:
                #     xpath = "//span[contains(@class,'MuiButton-label') and .//div[normalize-space()='承認']]"
                #     res = util.xpath_click(driver, xpath, 0)
                #     logger.info(f"承認処理を実施しました。")
                # else:
                #     logger.warning(f"金額不一致のため、承認処理は実施しませんでした。")
                
                ### ----- pdfファイルを削除 -----
                util.delete_file(pdf_path)
                
                ### ----- ウィンドウを閉じて元に戻る -----
                driver.close()
                driver.switch_to.window(original_window)
            
                logger.info(f"########## {element_text} 処理 END ##########")
        
        # 次ページへ
        xpath = "//button[.//p[normalize-space()='次へ']]"
        res = util.xpath_click(driver, xpath, 0)
        if res != 0:
            break
    
    
    
    