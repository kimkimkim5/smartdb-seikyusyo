import os
import re
import json
import pdfplumber
from typing import Dict, Any
import util
from openai import OpenAI

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))


def extract_text_from_pdf(pdf_path: str, max_pages: int = 5) -> str:
    """
    PDFからテキストを抽出する関数
    
    PDFからテキスト抽出（先頭max_pagesページ）
    請求書は1枚が多いので先頭だけで十分なことが多い。

    引数:
        pdf_path: PDFファイルのパス
        max_pages: 抽出する最大ページ数

    返り値:
        抽出したテキスト

    エラー:
        Exception

    著作権:
        Ryusuke Kimura (ogi.kimura@gmail.com)

    """
    texts = []
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages[:max_pages]):
            t = page.extract_text() or ""
            # 余計な空白を少し整形
            t = re.sub(r"[ \t]+", " ", t)
            texts.append(f"--- page {i+1} ---\n{t}")
    return "\n\n".join(texts).strip()



def extract_tax_amounts_via_openai(text: str) -> Dict[str, Any]:
    """
    PDFから抽出したテキストから、LLMを使って税込金額と消費税金額を取得する関数
    LLMにテキストを渡して、税込金額と消費税金額をJSONで返させる

    引数:
        text: PDFから抽出したテキスト
        max_pages: 抽出する最大ページ数

    返り値:
        税込金額と消費税金額を含む辞書
    エラー:
        Exception

    著作権:
        Ryusuke Kimura (ogi.kimura@gmail.com)

    """
    system = (
        "あなたは日本の請求書/領収書から金額情報を抽出するアシスタントです。"
        "与えられたテキストから『税込金額（総支払額）』と『消費税金額』を特定し、"
        "根拠となる行（抜粋）も返してください。"
        "不明な場合は null にしてください。推測で埋めないでください。"
    )

    user = f"""
以下はPDFから抽出したテキストです。ここから次を抽出してJSONで返してください。

- total_including_tax: 税込金額（合計・総支払額・請求金額など）
- consumption_tax: 消費税金額（消費税、税額、消費税等）
- evidence: それぞれの根拠となるテキスト断片（該当行を短く）

出力は必ず次のJSON形式のみ（余計な文章は禁止）:
{{
  "total_including_tax":   "<文字列 or null>",
  "consumption_tax":       "<文字列 or null>",
  "evidence": {{
    "total_including_tax": "<根拠行 or null>",
    "consumption_tax":     "<根拠行 or null>"
  }}
}}

テキスト:
{text}
"""

    resp = client.chat.completions.create(
        # model="gpt-4.1-mini",
        # temperature=0,
        model=util.OPENAI_MODEL,
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
    )

    content = resp.choices[0].message.content.strip()
    data = json.loads(content)

    # 正規化（整数化）も付けて返す
    total_raw = data.get("total_including_tax")
    tax_raw =   data.get("consumption_tax")

    return {
        "total_including_tax_raw":         total_raw,
        "consumption_tax_raw":             tax_raw,
        "total_including_tax":             util.normalize_money(total_raw),
        "consumption_tax":                 util.normalize_money(tax_raw),
        "evidence":                        data.get("evidence", {}),
    }

def main(pdf_path: str):
    """
    メイン関数

    引数:
        PDFファイルパス

    返り値:
        なし

    エラー:
        Exception

    著作権:
        Ryusuke Kimura (ogi.kimura@gmail.com)

    """
    text = extract_text_from_pdf(pdf_path, max_pages=5)
    if not text:
        raise RuntimeError("PDFからテキストを抽出できませんでした（画像PDFの可能性）。")

    result = extract_tax_amounts_via_openai(text)
    total_including_tax = result["total_including_tax"]
    consumption_tax     = result["consumption_tax"]
    try: 
        total_decluding_tax = result["total_including_tax"] - result["consumption_tax"]
    except TypeError:
        total_decluding_tax = 0
    
    # print(json.dumps(result, ensure_ascii=False, indent=2))
    return total_including_tax, consumption_tax, total_decluding_tax
